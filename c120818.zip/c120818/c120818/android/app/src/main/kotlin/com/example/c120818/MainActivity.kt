package com.example.c120818

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
